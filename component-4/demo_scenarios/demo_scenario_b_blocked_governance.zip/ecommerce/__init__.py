"""Ecommerce core package."""
