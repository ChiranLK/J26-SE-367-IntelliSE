"""Analytics calculations package."""
